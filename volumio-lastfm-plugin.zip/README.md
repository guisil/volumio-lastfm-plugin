# volumio-lastfm-plugin
Plugin to scrobble music played in Volumio 2.x to LastFM.
